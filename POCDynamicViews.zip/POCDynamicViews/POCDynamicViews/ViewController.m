//
//  ViewController.m
//  POCDynamicViews
//
//  Created by Prime Admin on 4/1/14.
//  Copyright (c) 2014 Prime Admin. All rights reserved.
//

#import "ViewController.h"
#import "ProtocoCell.h"

@interface ViewController ()

@end

@implementation ViewController

NSDictionary* dictionaryCities;

- (void)viewDidLoad
{
    [super viewDidLoad];
    services = [[Services alloc] init];
    dictionaryCities = [services getCities:nil];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)onClickButtonCriar:(id)sender {


    
    for (int i = 0; i < [self numberOfSectionsInTableView:tbItens]; i ++) {
        NSIndexPath *indexPath = [[NSIndexPath alloc] initWithIndex:i];
        [tbItens cellForRowAtIndexPath:indexPath];
    }


}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return  [[self retrieveDictionary]count];
}



- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {

    NSMutableArray * array = [self retrieveDictionary];
    
    NSString *type = [array objectAtIndex:indexPath.row];
    
    UITableViewCell *cell = nil;
    
    if([type isEqualToString:@"1"])
    {
      UITextViewCell  *cellTextField = [tableView dequeueReusableCellWithIdentifier:@"cell_text_field"];
      cell = cellTextField;
    }
    else
    {
      UIItemCell *cellItem = [tableView dequeueReusableCellWithIdentifier:@"cell_label"];
      cell = cellItem;
    }
    

    
    return cell;
}

- (NSMutableArray*) retrieveDictionary {
    NSMutableArray* array = [[NSMutableArray alloc] initWithObjects:@"1",@"2",@"1",@"2",@"1", nil];
    
    return array;
}




@end
