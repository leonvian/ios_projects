//
//  ViewController.h
//  POCDynamicViews
//
//  Created by Prime Admin on 4/1/14.
//  Copyright (c) 2014 Prime Admin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Services.h"
#import "UITextViewCell.h"
#import "UIItemCell.h"
#import "ProtocoCell.h"

@interface ViewController : UIViewController<UITableViewDataSource, UITableViewDelegate>{
    Services *services;
    __weak IBOutlet UITableView *tbItens;
    
}

- (IBAction)onClickButtonCriar:(id)sender;



@end
