//
//  UITextViewCell.h
//  POCDynamicViews
//
//  Created by Prime Admin on 4/1/14.
//  Copyright (c) 2014 Prime Admin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ProtocoCell.h"

@interface UITextViewCell : UITableViewCell<ProtocoCell>
@property (weak, nonatomic) IBOutlet UITextField *txtValor;

@end
