//
//  AppDelegate.h
//  POCDynamicViews
//
//  Created by Prime Admin on 4/1/14.
//  Copyright (c) 2014 Prime Admin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
